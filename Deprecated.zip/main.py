import logging

from utils.auth.otp import TOTPProvider
from utils.auth.credentials import Credentials
from utils.automation.core.browser_manager import BrowserManager
from utils.automation.experity.experity_base import ExperityBase
from utils.automation.experity.experity_reports import ExperityReports

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s - %(message)s")

credentials = Credentials("16", "sjalan@zny01", "Graphx@1110", "FH2MMUESLNQUHIH2")
logger = logging.getLogger("Automation Demo")
automation = ExperityReports(BrowserManager, ExperityBase)

try:
    automation.login(credentials, TOTPProvider)
    automation.clinic_data()
    automation.report_data()
except Exception as e:
    automation.collect_exception()
    logger.error("Exception during automation: %s", e)
finally:
    automation.logout()
    automation.close_browser()
