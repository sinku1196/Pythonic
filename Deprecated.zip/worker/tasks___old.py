import logging
from datetime import datetime
from dotenv import load_dotenv

import dramatiq

from logging_conf import configure_logging
from utils.automation import ExperityAutomation
from utils.date_formatter import get_months_between

load_dotenv()

configure_logging()
logger = logging.getLogger(__name__)


@dramatiq.actor(max_retries=3, min_backoff=1000)
def demo_browser_run(client_id: str = "16", from_date: str = "03/01/2005", to_date: str = "12/31/2025"):
    logger.info("Task started for client: %s", client_id)
    TODAY_DATE = datetime.now().strftime("%m/%d/%Y")
    months = get_months_between(from_date, to_date)
    logger.critical("Client ID: %s - START", client_id)
    automation = ExperityAutomation(headless=False, debug=False, timeout=30_000)
    try:
        automation.login(client_id=client_id)
        automation.report_data()
    except Exception as e:
        automation.collect_exception()
        logger.error("Exception during automation: %s", e)
    finally:
        automation.logout()
        automation.close_browser()
        logger.critical("Client ID: %s - END", client_id)
        logger.info("Task finished for client: %s", client_id)
