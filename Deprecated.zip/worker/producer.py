from tasks import demo_browser_run

if __name__ == "__main__":
    demo_browser_run.send("16")
    demo_browser_run.send("3622")
    demo_browser_run.send("3681")
