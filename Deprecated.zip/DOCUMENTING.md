# UC Experity Automation – Comprehensive Documentation Guide

Documentation is critical for maintaining clarity, collaboration, and long-term usability of code and processes.
This guide provides best practices for both **code-level documentation** (using Sphinx) and **human-readable documentation**.

---

## 1. Code-Level Documentation (Sphinx)

Code documentation ensures that scripts and modules are understandable, maintainable, and searchable. Sphinx allows converting docstrings into clean, structured documentation.

### Guidelines

1. **Use Sphinx and reStructuredText (reST)**

   - All docstrings should be compatible with Sphinx.

2. **Module-Level Docstrings**

   - Include the purpose of the module.
   - Add metadata:

     ```
     :Date: <YYYY-MM-DD>
     :Author(s): <Name(s)>
     ```

3. **Function and Class Documentation**

   - Provide a clear description of each function/class.
   - Document parameters with `:param:` and `:type:`.
   - Document return values with `:return:` and `:rtype:`.
   - Include any exceptions raised using `:raises:`.
   - Add usage examples using:

     ```
     .. code-block:: python
     ```

4. **Style and Structure**

   - Keep documentation concise but complete.
   - Use class-based structure where appropriate.
   - Only include documentation, not the code itself.

5. **Using LLMs to Assist**

   - You may use an LLM to generate draft documentation.
   - Always proofread and ensure consistency with Sphinx guidelines.

#### LLM Prompt Template

````
You are an expert Python developer and technical writer

Generate comprehensive Sphinx-style documentation for this script. Follow these guidelines:

1. Use **reStructuredText (reST)** formatting compatible with Sphinx.
2. Add a **module-level docstring** at the top, including:
   - Purpose of the module
   - `:Date:` with the current date
   - `:Author(s):` with the author's name(s)
3. For each **function** and **class**:
   - Include a clear description of its purpose.
   - List parameters with types and descriptions using `:param:` and `:type:` directives.
   - Include return values using `:return:` and `:rtype:` directives.
   - Include any exceptions raised using `:raises:` directives.
   - Provide examples if appropriate using:
     ```
     .. code-block:: python
     ```
4. Keep documentation concise, complete, and easy to read.
5. Use **class-based organization** where relevant.
6. Only provide the **documentation** (docstrings) without rewriting the code itself.

Make sure the documentation is consistent in style and format, ready to be integrated into the code.

I have the following Python script:
<INSERT YOUR PYTHON SCRIPT HERE>
````

---

## 2. Human-Focused Documentation

Human-readable documentation ensures that colleagues or users understand processes, tools, or systems.

### Best Practices

1. **Know Your Audience**

   - Adjust language and detail level to your readers’ knowledge.

2. **Be Clear and Concise**

   - Use simple, direct language.
   - Break content into digestible sections.

3. **Organize Logically**

   - Use headings, subheadings, and bullet points.
   - Follow a natural flow: introduction → details → examples → summary.

4. **Use Examples and Visuals**

   - Include code snippets, diagrams, screenshots, or tables to clarify concepts.

5. **Be Consistent**

   - Maintain consistent terminology, formatting, and style.

6. **Highlight Important Information**

   - Emphasize key points and include warnings where needed.

7. **Anticipate Questions**

   - Include clarifications and FAQs proactively.

8. **Review and Iterate**

   - Proofread for clarity and correctness.
   - Test readability with someone unfamiliar with the topic.

9. **Keep it Up to Date**

   - Regularly revise documentation as tools, code, or processes change.

10. **Write With Empathy**

    - Assume limited context; guide the reader without being condescending.

---

## 3. Summary Workflow

1. Write Sphinx-compatible docstrings for all modules, classes, and functions.
2. Use LLMs to generate or draft documentation where appropriate.
3. Review and proofread both code-level and human-focused docs.
4. Maintain consistency in style, terminology, and structure.
5. Update regularly to reflect changes in code or processes.

Perfect — your existing `documenting.md` is already a strong foundation. What you need now is a **practical guide for developers on how to document new code going forward** that directly ties into your Sphinx setup. Essentially, it should show **how to add docstrings in the style you’ve standardized**, without worrying about the initial Sphinx project setup.

Here’s a refined section you can append to your `documenting.md` specifically for **ongoing developer usage**:

---

## 4. Developer Guide: Documenting New Code (Sphinx)

This section provides step-by-step guidance for developers to document new Python modules, classes, and functions consistently.

### Step 1: Write Docstrings in Your Code

1. **Module-Level Docstring**
   Place at the top of your Python file:

   ```python
   """
   <Brief description of the module's purpose>

   :Date: 2025-12-29
   :Author(s): <Your Name>
   """
   ```

2. **Class Docstring**
   Place directly under the class definition:

   ```python
   class MyClass:
       """
       <Description of what this class represents or does>

       :param param1: Description of parameter 1
       :type param1: <type>
       :param param2: Description of parameter 2
       :type param2: <type>
       :raises ValueError: If <condition>
       """
   ```

3. **Function / Method Docstring**

   ```python
   def my_function(arg1: int, arg2: str) -> bool:
       """
       <Clear description of the function's purpose>

       :param arg1: Description of argument 1
       :type arg1: int
       :param arg2: Description of argument 2
       :type arg2: str
       :return: Description of return value
       :rtype: bool
       :raises KeyError: If <condition>

       .. code-block:: python

           Example usage:
           result = my_function(5, "example")
       """
   ```

4. **Type Hints**
   Include Python type hints where possible. Sphinx with `sphinx-autodoc-typehints` will display them automatically.

---

### Step 2: Keep Docstrings Consistent

- Use the **same style across all modules** (reST with `:param:`, `:type:`, `:return:`, `:rtype:`, `:raises:`).
- Include examples for complex functions.
- Be concise but informative — one paragraph is usually enough unless the function is complex.
- Update docstrings whenever functionality changes.

---

### Step 3: Updating Sphinx Documentation

Once new code is documented:

1. If you added new modules:

   ```bash
   sphinx-apidoc -o docs/source/ mypackage/
   ```

2. Rebuild the HTML documentation:

   ```bash
   cd docs/
   make html
   ```

3. Open `docs/build/html/index.html` to verify the new documentation appears correctly.

---

### Step 4: Optional — Use LLM to Draft Docstrings

If desired, use the LLM prompt template in **Section 1** to generate draft docstrings. Always **review and edit** to ensure accuracy and maintain your style guide.

---

This addition turns your `documenting.md` into a **living manual** for developers, covering both style and the technical steps to integrate documentation with Sphinx.

---

If you want, I can also create a **ready-made example module** with fully compliant Sphinx docstrings showing **module, class, function, exceptions, examples, and type hints** — this is often the fastest way for developers to model new code documentation.

Do you want me to do that?
