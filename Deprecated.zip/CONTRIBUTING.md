# UC Experity Automation – Contributing

Thank you for your interest in contributing to the UC Experity Automation project. Contributions of all kinds—code, documentation, bug fixes, and improvements—are welcome and appreciated.

## Contributing Guidelines
This document defines the standards, expectations, and processes to follow when contributing to ensure consistency, quality, and maintainability across the project.

## Project Overview

This project is focused on **browser-based automation using Python**. It leverages **Playwright** and supporting utilities to programmatically interact with the Experity portal in a reliable and maintainable manner.

Key characteristics of the project include:

* Python-based automation scripts
* Playwright for browser interaction
* Configuration-driven and environment-aware execution
* Emphasis on reliability, determinism, and maintainability

## Getting Started

### Prerequisites

Before contributing, ensure the following tools are installed and properly configured:

* Python **3.10.11**
* A virtual environment tool (`venv`, `virtualenv`, or equivalent)
* Playwright (installed via Python)
* Git (installed and authenticated with GitHub)

### Repository Setup

1. Fork the repository to your GitHub account.

2. Clone your fork locally:

   ```bash
   git clone https://github.com/GraphxSolutions/UC_Experity_Automation.git
   ```

3. Create and activate a virtual environment:

   ```bash
   python -m venv venv
   source venv/bin/activate    # Linux/macOS
   venv\Scripts\activate       # Windows
   ```

4. Install project dependencies:

   ```bash
   pip install -r requirements.txt
   ```

5. Install Playwright browsers (if not already installed):

   ```bash
   playwright install
   ```

## Development Guidelines

### Code Style and Structure

* Follow **PEP 8** Python style guidelines.
* Use clear, descriptive names for variables, functions, and classes.
* Keep functions small, focused, and single-purpose.
* Prefer composition over duplication; reuse shared utilities where possible.
* Avoid hard-coded values. Use configuration files or environment variables instead.

### Automation Best Practices

* Ensure scripts are:

  * **Deterministic**: identical inputs should always produce identical outputs.
  * **Idempotent** (where applicable): repeated execution should not introduce unintended side effects.
* Avoid fixed delays such as `time.sleep` unless absolutely necessary.

  * Prefer Playwright’s explicit or implicit waiting mechanisms.
* Manage browser lifecycle responsibly:

  * Ensure sessions are properly closed.
  * Clean up resources after execution.
* Do not automate against systems you do not own or for which you do not have explicit authorization.

### Testing and Validation

* Provide clear steps for manual verification when automated tests are not feasible.
* Ensure changes do not break existing workflows.
* Where possible, include logs or evidence demonstrating successful execution.

## Commit Guidelines

* Write clear, concise commit messages.
* Use the **imperative mood** (e.g., “Add login automation”, not “Added login automation”).
* Keep commits focused and atomic; avoid combining unrelated changes.

Example commit message:

```text
Fix element wait strategy for dynamic pages
```

## Pull Request Process

1. Create a feature or fix branch from `main`:

   ```bash
   git checkout -b feature/short-description
   ```

2. Implement your changes and commit them.

3. Push the branch to your forked repository.

4. Open a pull request targeting the `main` branch.

5. Ensure the pull request includes:

   * A clear description of the change
   * Motivation and context
   * Testing steps or supporting evidence (logs, screenshots, etc.)

Pull requests may be reviewed for:

* Code quality and readability
* Maintainability and scalability
* Security implications
* Alignment with project objectives

## Reporting Issues

If you encounter bugs or have feature requests:

* Review existing issues before creating a new one.
* Provide clear reproduction steps.
* Include relevant logs, error messages, and environment details (OS, Python version, etc.).

## Security Considerations

* Never commit credentials, access tokens, cookies, or sensitive data.
* Store secrets using environment variables or ignored configuration files.
* Report security vulnerabilities privately whenever possible.

---

Thank you for contributing to the UC Experity Automation project. Your efforts help improve reliability, quality, and long-term maintainability.
