import os
from datetime import datetime

DATE_STAMP = datetime.now().strftime("%Y-%m-%d")


def download_dir(client_id: str):
    return os.path.join("downloads", DATE_STAMP, client_id)


def screenshot_dir(client_id: str):
    return os.path.join("screenshots", DATE_STAMP, client_id)


def logs_dir(client_id: str):
    return os.path.join("logs", DATE_STAMP, client_id)
