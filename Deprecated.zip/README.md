# UC_Experity_Automation

Automation scripts for report and data extraction from the Experity portal.

## Contributing

* Refer [CONTRIBUTING.md](CONTRIBUTING.md) for detailed information about contributing to this project.