import argparse


def automation_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Download clinic data for a specified client",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    runtime_group = parser.add_argument_group("Runtime Options")
    runtime_group.add_argument(
        "--client-id",
        type=str,
        default="16",
        dest="client_id",
        help="Client ID to download clinic data for",
    )

    runtime_group.add_argument(
        "--headless",
        action="store_true",
        default=True,
        help="Run browser in headless mode",
    )

    runtime_group.add_argument(
        "--no-headless",
        action="store_false",
        dest="headless",
        help="Run browser with visible UI (disable headless mode)",
    )

    logging_group = parser.add_argument_group("Logging Options")
    logging_group.add_argument(
        "-t",
        "--terminal-output",
        action="store_true",
        dest="terminal_output",
        help="Print logs to terminal instead of file",
    )

    return parser


def data_load_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Load clinic data for the specified client",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    runtime_group = parser.add_argument_group("Runtime Options")
    runtime_group.add_argument(
        "--client-id",
        type=str,
        default="16",
        dest="client_id",
        help="Client ID to load clinic data for",
    )

    logging_group = parser.add_argument_group("Logging Options")
    logging_group.add_argument(
        "-t",
        "--terminal-output",
        action="store_true",
        dest="terminal_output",
        help="Print logs to terminal instead of file",
    )

    return parser
