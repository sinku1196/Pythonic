import os
import logging
from datetime import datetime
from dotenv import load_dotenv

from utils.automation import ExperityAutomation
from utils.date_formatter import get_months_between

load_dotenv()

# TODO: Make client id dynamic that can passed as argument
CLIENT_ID = "16"

logs_dir = os.path.join("logs", str(datetime.now().strftime("%Y-%m-%d")))
os.makedirs(logs_dir, exist_ok=True)
log_file = os.path.join(logs_dir, f"{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.log")
logging.basicConfig(filename=log_file, filemode="a", level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s - %(message)s")
# logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s - %(message)s")
logger = logging.getLogger("Experity_Automation")

# TODO: Make Start Date Dynamic
START_DATE = "03/01/2005"
END_DATE = "12/31/2025"

# TODO: Step 1: Get the clinics
# TODO: Step 2: Get the report list
# TODO: Step 3: Get the start date
# TODO: Step 4: Create reports config
# TODO: Step 5: Check which reports are already present on the disk
# TODO: Step 6: Based on file availability dynamically create download task

TODAY_DATE = datetime.now().strftime("%m/%d/%Y")
months = get_months_between(START_DATE, END_DATE)

for CLIENT_ID in CLIENT_IDS:
    logger.critical("Client ID: %s - START", CLIENT_ID)
    automation = ExperityAutomation(headless=False, debug=False, timeout=30_000)
    try:
        automation.login(client_id=CLIENT_ID)
        automation.report_data()
        # automation.month_range_report("PAY 28", "Expected AR, PAY 28", months[0], months[-1])
        # # Adjustments - Month Range Reports
        # automation.month_range_report_monthly("ADJ 0", "Financials, ADJ 0", months)
        # automation.month_range_report("ADJ 8", "Financials, ADJ 8", months[0], months[-1])

        # # Adjustments - Month Reports
        # automation.month_report("ADJ 1", "Financials, ADJ 1", months)
        # automation.month_report("ADJ 2", "Financials, ADJ 2", months)
        # automation.month_report("ADJ 3", "Financials, ADJ 3", months)
        # automation.month_report("ADJ 4", "Financials, ADJ 4", months)
        # automation.month_report("ADJ 6", "Financials, ADJ 6", months)

        # automation.month_report("CNT 4", "Practice, CNT 4", months)
        # automation.month_range_report("CNT 9 DW", "Practice, CNT 9 DW", months[0], months[-1])
        # automation.date_range_report("CNT 39", "Practice, CNT 39", START_DATE, TODAY_DATE)
        # automation.date_range_report("CNT 23", "Practice, CNT 23", START_DATE, TODAY_DATE)
        # automation.date_range_report("CNT 17", "Practice, CNT 17", START_DATE, TODAY_DATE)
        # automation.date_range_report("CNT 12", "Practice, CNT 12", START_DATE, TODAY_DATE)
        # automation.date_range_report("CNT 13", "Practice, CNT 13", START_DATE, TODAY_DATE)
    except Exception as e:
        automation.collect_exception()
        logger.error("Exception during automation: %s", e)
    finally:
        automation.logout()
        automation.close_browser()
        logger.critical("Client ID: %s - END", CLIENT_ID)
