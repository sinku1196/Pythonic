# UC Experity Automation - Change Log

## Project Setup

- Contribution Guidelines [CONTRIBUTING.md](CONTRIBUTING.md)
- Project setup

**Commit** - Setup project

## 2025_12_29

- Create module for browser manager, experity base, and totp generator

**Commit** - Create base modules for automation
