from collections import namedtuple

ExperityCredentails = namedtuple("ExperityCredentails", ["client_id", "username", "password", "passphrase"])
