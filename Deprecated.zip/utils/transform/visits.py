from utils.transform.transformer import DataTransformer


transformer = DataTransformer()


class Visits:
    def __init__(self, transformer: DataTransformer) -> None:
        self.transformer = transformer

    def cnt_4(self, input_file: str, output_file: str) -> None:
        self.transformer.transform(
            input_file,
            output_file,
            drop_columns=["textbox2", "textbox4"],
            rename_columns={
                "Svc_Date": "ServiceDate",
                "Visit": "VisitType",
                "Phy_Name": "Physician",
                "Pat_Num": "PatientNumber",
                "Pat_Name": "PatientName",
            },
        )

    def cnt_9_dw(self, input_file: str, output_file: str) -> None:
        self.transformer.transform(
            input_file,
            output_file,
            drop_columns=[
                "textbox22",
                "textbox24",
                "textbox25",
                "textbox26",
                "textbox27",
                "textbox28",
                "textbox25",
                "textbox68",
                "textbox69",
                "textbox70",
                "textbox71",
                "textbox72",
                "textbox73",
                "textbox9",
                "textbox10",
                "textbox11",
                "textbox12",
                "textbox13",
                "textbox14",
            ],
            rename_columns={
                "textbox64": "Month-Year",
                "textbox21": "Clinic",
                "textbox17": "VisitType",
            },
            currency_columns=[
                "Charges",
                "AvgChargesPerPatient",
                "AvgChargesPerVisit",
                "AvgVisitsPerPatient",
            ],
        )

    def cnt_17(self, input_file: str, output_file: str) -> None:
        self.transformer.transform(
            input_file,
            output_file,
            drop_columns=[
                "textbox22",
                "textbox24",
                "textbox41",
                "textbox38",
                "textbox25",
                "textbox26",
                "textbox11",
                "textbox12",
                "textbox13",
                "textbox14",
                "textbox37",
                "textbox16",
                "textbox17",
                "textbox18",
                "textbox19",
                "textbox40",
                "textbox79",
                "textbox73",
                "textbox74",
                "textbox75",
                "textbox76",
                "textbox77",
                "Clinic1",
                "Phy_Name1",
                "textbox70",
                "textbox5",
                "textbox43",
                "textbox44",
                "textbox45",
                "textbox46",
                "textbox47",
            ],
            rename_columns={
                "Svc_Date": "ServiceDate",
                "Phy_Name": "Physician",
                "Financial_Class": "FinancialClass",
            },
        )

    def cnt_39(self, input_file: str, output_file: str) -> None:
        self.transformer.transform(
            input_file,
            output_file,
            drop_columns=[
                "Practice2",
                "Clinic2",
                "textbox33",
                "textbox34",
                "textbox35",
                "textbox36",
                "textbox37",
                "Practice2",
                "Svc_Date1",
            ],
            rename_columns={
                "Clinic1": "Clinic",
            },
        )


if __name__ == "__main__":
    import os
    from transformer import DataTransformer

    os.makedirs(r"transformed\16\2026-01-16", exist_ok=True)
    transformer = DataTransformer()
    visits_transformer = Visits(transformer)
    cnt_4_input_path = r"downloads\16\2026-01-16\CNT_4_August_2024.csv"
    cnt_4_output_path = r"transformed\16\2026-01-16\CNT_4_August_2024.csv"
    visits_transformer.cnt_4(cnt_4_input_path, cnt_4_output_path)
