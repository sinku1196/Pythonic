import polars as pl
from typing import Dict, List, Optional


class DataTransformer:
    """
    UC Data Decoder & Transformer for ADJ reports.
    """

    def clean_currency_column(df: pl.DataFrame, column: str) -> pl.DataFrame:
        """
        Cleans a currency column by:
          - Converting accounting negatives like (1,234.56) → -1234.56
          - Removing '$', ',', and whitespace
          - Casting safely to Float64
        """
        cleaned_col = pl.col(column).str.strip_chars().str.replace_all(r"[\$,]", "").str.replace_all(r"^\((.*)\)$", r"-$1").cast(pl.Float64)

        return df.with_columns(cleaned_col.alias(column))

    def transform(
        self,
        input_file: str,
        output_file: str,
        skip_rows: int = 0,
        drop_columns: Optional[List[str]] = None,
        rename_columns: Optional[Dict[str, str]] = None,
        currency_columns: Optional[List[str]] = None,
        add_columns: Optional[Dict[str, object]] = None,
    ) -> None:
        """
        Generic transformation logic for ADJ reports.
        """
        # Step 1: Read CSV skipping first N rows
        df = pl.read_csv(input_file, skip_rows=skip_rows, infer_schema_length=None)

        # Remove completely null rows
        df = df.filter(~pl.all_horizontal(pl.all().is_null()))

        # Step 2: Drop unnecessary columns
        if drop_columns:
            df = df.drop([col for col in drop_columns if col in df.columns])

        # Step 3: Rename columns
        if rename_columns:
            df = df.rename(rename_columns)

        # Step 4: Clean currency columns
        if currency_columns:
            for col in currency_columns:
                if col in df.columns:
                    df = self._clean_currency_column(df, col)

        # Step 5: Add new columns with constant values
        if add_columns:
            for col_name, value in add_columns.items():
                df = df.with_columns(pl.lit(value).alias(col_name))

        # Step 6: Save transformed file
        df.write_csv(output_file)
