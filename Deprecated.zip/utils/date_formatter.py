# date_formatter.py

from datetime import datetime
from typing import List


def get_months_between(start_date: str, end_date: str) -> List[str]:
    """
    Generate all months between start and end dates in 'MonthName Year' format.

    Args:
        start_date (str): Start date in MM/DD/YYYY format
        end_date (str): End date in MM/DD/YYYY format

    Returns:
        List[str]: List of months in 'MonthName Year' format

    Raises:
        ValueError: If input dates are invalid or improperly formatted
    """
    date_format = "%m/%d/%Y"

    start = datetime.strptime(start_date, date_format)
    end = datetime.strptime(end_date, date_format)

    if start > end:
        raise ValueError("Start date must be earlier than or equal to end date")

    months = []
    current_year = start.year
    current_month = start.month

    while (current_year, current_month) <= (end.year, end.month):
        current_date = datetime(current_year, current_month, 1)
        months.append(current_date.strftime("%B %Y"))

        # Increment month
        if current_month == 12:
            current_month = 1
            current_year += 1
        else:
            current_month += 1

    return months


if __name__ == "__main__":
    # Example usage
    result = get_months_between("01/15/2022", "05/20/2022")
    for month in result:
        print(month)
